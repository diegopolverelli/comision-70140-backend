

export const config={
    PORT:3000,
    MONGO_URL:"mongodb+srv://comis70140:CoderCoder@cluster0.3rdsx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    DB_NAME:"clase14",
    // SECRET:"CoderCoder123"
}